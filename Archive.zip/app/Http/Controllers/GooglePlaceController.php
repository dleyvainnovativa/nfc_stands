<?php

namespace App\Http\Controllers;

use App\Models\GooglePlace;
use App\Services\GooglePlaces;
use App\Support\CurrentTenant;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;

class GooglePlaceController extends Controller
{
    public function index()
    {
        $places = GooglePlace::orderBy('label')->orderBy('id')->get();

        $trends = [];
        foreach ($places as $p) {
            $trends[$p->id] = $p->trend(30);
        }

        $keyConfigured = ! empty(config('googleplaces.key'));

        return view('google.index', compact('places', 'trends', 'keyConfigured'));
    }

    public function store(Request $request, GooglePlaces $service)
    {
        $this->guardTenantContext();

        $data = $request->validate([
            'place_id' => ['required', 'string', 'min:5', 'max:300'],
            'label' => ['nullable', 'string', 'max:120'],
        ]);

        $place = GooglePlace::firstOrNew([
            'tenant_id' => CurrentTenant::id(),
            'place_id' => trim($data['place_id']),
        ]);

        if ($place->exists) {
            return back()->with('flash.warning', 'That place is already connected.');
        }

        $place->label = $data['label'] ?? null;
        $place->save(); // tenant_id auto-fills

        // Immediate first sync so the card isn't empty.
        $ok = $service->sync($place);

        return redirect()->route('google.index')->with(
            $ok ? 'flash.success' : 'flash.warning',
            $ok ? 'Place connected and synced.' : 'Place added, but the first sync failed — check the API key / place ID, then Sync again.'
        );
    }

    public function sync(Request $request, GooglePlaces $service, ?GooglePlace $place = null)
    {
        if ($place) {
            $ok = $service->sync($place);
            return back()->with($ok ? 'flash.success' : 'flash.error',
                $ok ? 'Synced.' : ('Sync failed: ' . $place->sync_error));
        }

        // Sync all of the tenant's places.
        $places = GooglePlace::all();
        $fail = 0;
        foreach ($places as $p) {
            if (! $service->sync($p)) $fail++;
        }
        return back()->with($fail ? 'flash.warning' : 'flash.success',
            $fail ? "Synced with {$fail} failure(s)." : 'All places synced.');
    }

    public function destroy(GooglePlace $place)
    {
        $place->delete();
        return redirect()->route('google.index')->with('flash.success', 'Place removed.');
    }

    private function guardTenantContext(): void
    {
        if (CurrentTenant::id() === null) {
            throw new HttpResponseException(
                redirect()->route('google.index')->with(
                    'flash.warning',
                    'Pick a tenant first (use "View as" on a tenant) to connect a place.'
                )
            );
        }
    }
}
