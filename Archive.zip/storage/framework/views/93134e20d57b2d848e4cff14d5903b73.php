<?php $__env->startSection('title', 'Edit survey · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Edit survey'); ?>

<?php
    use App\Models\SurveyQuestion;
    $typeOpts = SurveyQuestion::typeOptions();
?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <a href="<?php echo e(route('surveys.index')); ?>" class="text-muted-2" style="font-size:.9rem">
        <i class="fa-solid fa-arrow-left me-1"></i> Surveys
    </a>
    <div class="d-flex align-items-center gap-2">
        <code class="text-muted-2" style="font-size:.82rem"><?php echo e($survey->publicUrl()); ?></code>
        <a href="<?php echo e(route('surveys.show', $survey)); ?>" class="btn btn-outline-secondary btn-sm">Results</a>
    </div>
</div>

<form method="POST" action="<?php echo e(route('surveys.update', $survey)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    
    <div class="card mb-4" style="max-width:820px">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" value="<?php echo e(old('title', $survey->title)); ?>" class="form-control" maxlength="160" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <?php $__currentLoopData = ['draft'=>'Draft','active'=>'Active','closed'=>'Closed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v); ?>" <?php if(old('status',$survey->status)===$v): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Description <span class="text-subtle">(optional)</span></label>
                    <textarea name="description" class="form-control" rows="2" maxlength="1000"><?php echo e(old('description', $survey->description)); ?></textarea>
                </div>
                <div class="col-12">
                    <label class="form-label">Thank-you message <span class="text-subtle">(optional)</span></label>
                    <input type="text" name="thank_you_message" value="<?php echo e(old('thank_you_message', $survey->thank_you_message)); ?>" class="form-control" maxlength="300" placeholder="Thanks for your feedback!">
                </div>
            </div>
        </div>
    </div>

    
    <div class="d-flex align-items-center justify-content-between mb-2" style="max-width:820px">
        <h2 class="h6 fw-bold mb-0">Questions</h2>
    </div>

    <div id="questions" class="d-flex flex-column gap-3" style="max-width:820px">
        <?php $__currentLoopData = $survey->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('surveys._question_row', [
                'idx' => $i,
                'q' => $q,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-3" style="max-width:820px">
        <button type="button" id="addQuestion" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-plus me-1"></i> Add question
        </button>
    </div>

    <div class="d-flex gap-2 mt-4" style="max-width:820px">
        <button class="btn btn-primary">Save survey</button>
        <a href="<?php echo e(route('surveys.index')); ?>" class="btn btn-outline-secondary">Done</a>
    </div>
</form>


<template id="qTemplate">
    <?php echo $__env->make('surveys._question_row', ['idx' => '__IDX__', 'q' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</template>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    const wrap = document.getElementById('questions');
    const tpl = document.getElementById('qTemplate').innerHTML;
    let counter = <?php echo e($survey->questions->count()); ?>;

    function wire(row) {
        const typeSel = row.querySelector('[data-role="type"]');
        const toggle = () => {
            const t = typeSel.value;
            row.querySelector('[data-for="options"]').classList.toggle('d-none', !(t === 'single' || t === 'multi'));
            row.querySelector('[data-for="rating"]').classList.toggle('d-none', t !== 'rating');
        };
        typeSel.addEventListener('change', toggle); toggle();

        row.querySelector('[data-act="remove"]').addEventListener('click', () => row.remove());
        row.querySelector('[data-act="up"]').addEventListener('click', () => {
            const prev = row.previousElementSibling; if (prev) wrap.insertBefore(row, prev);
        });
        row.querySelector('[data-act="down"]').addEventListener('click', () => {
            const next = row.nextElementSibling; if (next) wrap.insertBefore(next, row);
        });
    }

    wrap.querySelectorAll('.q-row').forEach(wire);

    document.getElementById('addQuestion').addEventListener('click', () => {
        const html = tpl.replaceAll('__IDX__', 'n' + (counter++));
        const tmp = document.createElement('div');
        tmp.innerHTML = html.trim();
        const row = tmp.firstElementChild;
        wrap.appendChild(row);
        wire(row);
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/surveys/edit.blade.php ENDPATH**/ ?>