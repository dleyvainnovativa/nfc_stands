<?php $__env->startSection('title', 'Blank tags · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Blank tags'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
    <div>
        <h1 class="h4 fw-bold mb-1">Blank tags</h1>
        <p class="text-muted-2 mb-0" style="font-size:.9rem">
            Pre-generate codes to encode onto physical NFC stickers. Clients claim them by code.
        </p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('admin.tags.qr_sheet')); ?>" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-qrcode me-1"></i> Print QR sheet
        </a>
        <a href="<?php echo e(route('admin.tags.export')); ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-file-csv me-1"></i> Export all (CSV)
        </a>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h2 class="h6 fw-bold mb-3">Generate</h2>
                <form method="POST" action="<?php echo e(route('admin.tags.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <label class="form-label">How many?</label>
                    <input type="number" name="count" min="1" max="500" value="25"
                           class="form-control <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="form-text text-muted-2 mb-3">Up to 500 per batch.</div>
                    <button class="btn btn-primary w-100">Generate tags</button>
                </form>

                <?php if(session('generated_codes')): ?>
                    <hr class="hr-token my-3">
                    <div class="fw-semibold mb-2" style="font-size:.85rem">Just generated</div>
                    <div class="mono" style="font-size:.8rem;max-height:160px;overflow:auto">
                        <?php $__currentLoopData = session('generated_codes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($c); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Unclaimed tags</span>
                <span class="text-muted-2" style="font-size:.85rem"><?php echo e($blanks->total()); ?> total</span>
            </div>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr class="text-muted-2" style="font-size:.8rem">
                            <th class="ps-3">Code</th><th>Public URL</th><th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $blanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-3 mono"><?php echo e($b->code); ?></td>
                                <td class="text-muted-2" style="font-size:.85rem"><?php echo e(url('/t/' . $b->code)); ?></td>
                                <td class="text-muted-2" style="font-size:.85rem"><?php echo e($b->created_at?->format('d M Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="text-center text-muted-2 py-4">No blank tags. Generate a batch to start.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-3"><?php echo e($blanks->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/admin/tags.blade.php ENDPATH**/ ?>