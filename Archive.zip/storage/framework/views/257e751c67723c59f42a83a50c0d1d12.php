<?php $__env->startSection('title', 'Stands · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Stands'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <h1 class="h4 fw-bold mb-0">Stands</h1>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('stands.claim')); ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-plus-circle me-1"></i> Claim a tag
        </a>
        <a href="<?php echo e(route('stands.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-plus me-1"></i> New stand
        </a>
    </div>
</div>

<form method="GET" class="row g-2 mb-3" style="max-width:560px">
    <div class="col">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm"
               placeholder="Search label or code…">
    </div>
    <div class="col-auto">
        <select name="status" class="form-select form-select-sm">
            <option value="">All statuses</option>
            <?php $__currentLoopData = ['active' => 'Active', 'unassigned' => 'Unassigned', 'disabled' => 'Disabled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($v); ?>" <?php if(request('status') === $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-auto">
        <button class="btn btn-outline-secondary btn-sm">Filter</button>
    </div>
</form>

<div class="card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr class="text-muted-2" style="font-size:.8rem">
                    <th class="ps-3">Label</th>
                    <th>Code</th>
                    <th>Destination</th>
                    <th>Status</th>
                    <th class="text-end">Scans</th>
                    <th>Last scan</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $stands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-3 fw-semibold"><?php echo e($stand->label ?: '—'); ?></td>
                        <td><code><?php echo e($stand->code); ?></code></td>
                        <td class="text-muted-2"><?php echo e(\App\Models\Stand::typeOptions()[$stand->destination_type] ?? $stand->destination_type); ?></td>
                        <td>
                            <?php ($cls = match($stand->status){ 'active' => 'success', 'disabled' => 'danger', default => 'warning' }); ?>
                            <span class="badge-role" style="background:var(--<?php echo e($cls); ?>-soft);color:var(--<?php echo e($cls); ?>)">
                                <?php echo e($stand->statusLabel()); ?>

                            </span>
                        </td>
                        <td class="text-end mono"><?php echo e(number_format($stand->scans_total)); ?></td>
                        <td class="text-muted-2" style="font-size:.86rem">
                            <?php echo e($stand->last_scan_at?->diffForHumans() ?? '—'); ?>

                        </td>
                        <td class="text-end pe-3">
                            <a href="<?php echo e(route('stands.show', $stand)); ?>" class="btn btn-sm btn-outline-secondary">Open</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted-2 py-5">
                            No stands yet. <a href="<?php echo e(route('stands.create')); ?>">Create one</a> or
                            <a href="<?php echo e(route('stands.claim')); ?>">claim a tag</a>.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3"><?php echo e($stands->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/stands/index.blade.php ENDPATH**/ ?>