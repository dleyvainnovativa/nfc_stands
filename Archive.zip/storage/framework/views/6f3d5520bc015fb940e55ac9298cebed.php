<?php
    use App\Models\SurveyQuestion;
    $typeOpts = SurveyQuestion::typeOptions();
    $name = "q[{$idx}]";
    $qType = $q->type ?? 'single';
    $qPrompt = $q->prompt ?? '';
    $qRequired = $q?->required ?? false;
    $qOptions = $q && is_array($q->options) ? implode("\n", $q->options) : '';
    $qMax = $q?->ratingMax() ?? 5;
    $isChoice = in_array($qType, ['single','multi'], true);
?>
<div class="card q-row">
    <div class="card-body">
        <div class="d-flex align-items-center gap-2 mb-3">
            <i class="fa-solid fa-grip-vertical text-subtle"></i>
            <select name="<?php echo e($name); ?>[type]" data-role="type" class="form-select form-select-sm" style="max-width:190px">
                <?php $__currentLoopData = $typeOpts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($v); ?>" <?php if($qType === $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="form-check ms-2 mb-0">
                <input type="checkbox" class="form-check-input" id="<?php echo e($idx); ?>_req"
                       name="<?php echo e($name); ?>[required]" value="1" <?php if($qRequired): echo 'checked'; endif; ?>>
                <label class="form-check-label text-muted-2" for="<?php echo e($idx); ?>_req" style="font-size:.85rem">Required</label>
            </div>
            <div class="ms-auto d-flex gap-1">
                <button type="button" class="icon-btn" data-act="up" title="Move up"><i class="fa-solid fa-chevron-up"></i></button>
                <button type="button" class="icon-btn" data-act="down" title="Move down"><i class="fa-solid fa-chevron-down"></i></button>
                <button type="button" class="icon-btn" data-act="remove" title="Remove" style="color:var(--danger)"><i class="fa-solid fa-trash"></i></button>
            </div>
        </div>

        <?php if($q): ?>
            <input type="hidden" name="<?php echo e($name); ?>[id]" value="<?php echo e($q->id); ?>">
        <?php endif; ?>

        <input type="text" name="<?php echo e($name); ?>[prompt]" class="form-control mb-2"
               placeholder="Question prompt" maxlength="255" value="<?php echo e($qPrompt); ?>">

        
        <div data-for="options" class="<?php echo e($isChoice ? '' : 'd-none'); ?>">
            <label class="form-label mt-1">Options <span class="text-subtle">(one per line, min 2)</span></label>
            <textarea name="<?php echo e($name); ?>[options]" class="form-control" rows="3" placeholder="Option A&#10;Option B"><?php echo e($qOptions); ?></textarea>
        </div>

        
        <div data-for="rating" class="<?php echo e($qType === 'rating' ? '' : 'd-none'); ?>" style="max-width:160px">
            <label class="form-label mt-1">Max rating</label>
            <input type="number" name="<?php echo e($name); ?>[rating_max]" class="form-control" min="2" max="10" value="<?php echo e($qMax); ?>">
        </div>
    </div>
</div>
<?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/surveys/_question_row.blade.php ENDPATH**/ ?>