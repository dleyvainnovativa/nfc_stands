<?php ($u = auth()->user()); ?>
<?php ($acting = \App\Support\CurrentTenant::isActingAs()); ?>
<header class="topbar">
    <button class="icon-btn" id="sidebarToggle" type="button" aria-label="Toggle menu">
        <i class="fa-solid fa-bars"></i>
    </button>

    <div class="page-title"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></div>

    <div class="spacer"></div>

    <?php if($u->isSuperAdmin() && $acting): ?>
        <?php ($actingTenant = \App\Support\CurrentTenant::model()); ?>
        <span class="badge-role" style="background:var(--warning-soft);color:var(--warning)">
            <i class="fa-solid fa-eye"></i> Viewing: <?php echo e($actingTenant?->name); ?>

        </span>
        <form method="POST" action="<?php echo e(route('tenant.exit')); ?>" class="d-inline">
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm btn-outline-secondary" type="submit">Exit</button>
        </form>
    <?php endif; ?>

    <button class="icon-btn" data-theme-toggle type="button" aria-label="Toggle theme" title="Toggle light/dark">
        <i class="fa-solid fa-circle-half-stroke"></i>
    </button>

    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-sm btn-outline-secondary" type="submit">
            <i class="fa-solid fa-arrow-right-from-bracket me-1"></i> Sign out
        </button>
    </form>
</header>
<?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/partials/topbar.blade.php ENDPATH**/ ?>