<?php $__env->startSection('title', ($stand->label ?: $stand->code) . ' · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Stand'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <a href="<?php echo e(route('stands.index')); ?>" class="text-muted-2" style="font-size:.9rem">
        <i class="fa-solid fa-arrow-left me-1"></i> Stands
    </a>
</div>

<div class="d-flex align-items-start justify-content-between flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h4 fw-bold mb-1"><?php echo e($stand->label ?: 'Untitled stand'); ?></h1>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <?php ($cls = match($stand->status){ 'active' => 'success', 'disabled' => 'danger', default => 'warning' }); ?>
            <span class="badge-role" style="background:var(--<?php echo e($cls); ?>-soft);color:var(--<?php echo e($cls); ?>)"><?php echo e($stand->statusLabel()); ?></span>
            <span class="text-muted-2" style="font-size:.88rem"><?php echo e(\App\Models\Stand::typeOptions()[$stand->destination_type] ?? $stand->destination_type); ?></span>
        </div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('stands.edit', $stand)); ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-pen me-1"></i> Edit
        </a>
        <form method="POST" action="<?php echo e(route('stands.destroy', $stand)); ?>"
              onsubmit="return confirm('Delete this stand? Scan history is removed too.')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn btn-outline-secondary btn-sm" style="color:var(--danger)"><i class="fa-solid fa-trash"></i></button>
        </form>
    </div>
</div>

<div class="row g-4 mb-4">
    
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-body d-flex align-items-center gap-2 flex-wrap">
                <span class="text-muted-2" style="font-size:.85rem">Tag URL</span>
                <code id="pubUrl" class="flex-grow-1"><?php echo e($stand->publicUrl()); ?></code>
                <button class="btn btn-outline-secondary btn-sm" id="copyUrl" type="button">
                    <i class="fa-regular fa-copy me-1"></i> Copy
                </button>
                <a href="<?php echo e($stand->publicUrl()); ?>" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm">
                    <i class="fa-solid fa-arrow-up-right-from-square me-1"></i> Test
                </a>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-body d-flex align-items-center gap-3">
                <img src="<?php echo e(route('stands.qr', $stand)); ?>" alt="QR for <?php echo e($stand->code); ?>"
                     width="92" height="92" style="border-radius:8px;background:#fff;padding:4px;border:1px solid var(--border)">
                <div>
                    <div class="fw-semibold" style="font-size:.92rem">QR code</div>
                    <div class="text-muted-2 mb-2" style="font-size:.82rem">For non-NFC phones. Points to the same tag URL.</div>
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('stands.qr.print', $stand)); ?>" target="_blank" rel="noopener" class="btn btn-outline-secondary btn-sm">
                            <i class="fa-solid fa-print me-1"></i> Print
                        </a>
                        <a href="<?php echo e(route('stands.qr', $stand)); ?>?dl=1" class="btn btn-outline-secondary btn-sm">
                            <i class="fa-solid fa-download me-1"></i> SVG
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-4">
        <div class="card stat-card h-100"><div class="stat-label">Total scans</div>
            <div class="stat-value"><?php echo e(number_format($stand->scans_total)); ?></div></div>
    </div>
    <div class="col-6 col-md-4">
        <div class="card stat-card h-100"><div class="stat-label">Scans (30d)</div>
            <div class="stat-value"><?php echo e(number_format(array_sum($chart['data']))); ?></div></div>
    </div>
    <div class="col-12 col-md-4">
        <div class="card stat-card h-100"><div class="stat-label">Last scan</div>
            <div class="stat-value" style="font-size:1.15rem"><?php echo e($stand->last_scan_at?->diffForHumans() ?? '—'); ?></div></div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header">Scans · last 30 days</div>
    <div class="card-body"><canvas id="scanChart" height="90"></canvas></div>
</div>

<?php if($stand->destination_type === \App\Models\Stand::TYPE_HUB): ?>
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>Link clicks</span>
            <?php ($ctr = $stand->scans_total > 0 ? round($totalClicks / $stand->scans_total * 100) : null); ?>
            <span class="text-muted-2" style="font-size:.85rem">
                <?php echo e(number_format($totalClicks)); ?> clicks <?php if($ctr !== null): ?>· <?php echo e($ctr); ?>% of scans tapped a link <?php endif; ?>
            </span>
        </div>
        <div class="card-body">
            <?php if($clicks->isEmpty()): ?>
                <div class="text-muted-2" style="font-size:.9rem">No link taps recorded yet.</div>
            <?php else: ?>
                <div class="d-flex flex-column gap-2">
                    <?php $__currentLoopData = $clicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($pct = $totalClicks > 0 ? round($c->clicks / $totalClicks * 100) : 0); ?>
                        <div>
                            <div class="d-flex justify-content-between" style="font-size:.88rem">
                                <span class="text-truncate" style="max-width:70%"><?php echo e($c->label ?: $c->url); ?></span>
                                <span class="text-muted-2"><?php echo e(number_format($c->clicks)); ?> · <?php echo e($pct); ?>%</span>
                            </div>
                            <div style="height:8px;border-radius:999px;background:var(--bg-sunken);overflow:hidden;margin-top:3px">
                                <div style="height:100%;width:<?php echo e($pct); ?>%;background:var(--accent);border-radius:999px"></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-header">Recent scans</div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr class="text-muted-2" style="font-size:.8rem"><th class="ps-3">When</th><th>Device</th><th>Referer</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-3" style="font-size:.88rem"><?php echo e($ev->occurred_at->format('d M, H:i')); ?></td>
                        <td><span class="text-muted-2"><?php echo e(ucfirst($ev->device ?? '—')); ?></span></td>
                        <td class="text-muted-2 text-truncate" style="max-width:260px;font-size:.85rem"><?php echo e($ev->referer ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="text-center text-muted-2 py-4">No scans yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js"></script>
<script>
    (function () {
        const el = document.getElementById('scanChart');
        if (!el || !window.Chart) return;
        const css = getComputedStyle(document.documentElement);
        const accent = css.getPropertyValue('--accent').trim() || '#5b5bd6';
        const muted = css.getPropertyValue('--text-muted').trim() || '#667085';
        const grid = css.getPropertyValue('--border').trim() || '#e4e7ec';
        new Chart(el, {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_map(fn($d) => \Illuminate\Support\Carbon::parse($d)->format('d M'), $chart['labels']), 512) ?>,
                datasets: [{ data: <?php echo json_encode($chart['data'], 15, 512) ?>, borderColor: accent, backgroundColor: accent + '22',
                    fill: true, tension: 0.3, pointRadius: 0, borderWidth: 2 }]
            },
            options: {
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false }, ticks: { color: muted, maxTicksLimit: 8 } },
                    y: { beginAtZero: true, grid: { color: grid }, ticks: { color: muted, precision: 0 } }
                }
            }
        });
        document.getElementById('copyUrl')?.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(document.getElementById('pubUrl').textContent.trim());
                window.App?.toast('Tag URL copied', 'success');
            } catch (e) { window.App?.toast('Copy failed', 'error'); }
        });
    })();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/stands/show.blade.php ENDPATH**/ ?>