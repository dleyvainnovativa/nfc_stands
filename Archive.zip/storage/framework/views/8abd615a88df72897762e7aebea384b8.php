<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
      data-theme="<?php echo e(request()->cookie('theme', 'light')); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thanks</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>
<div style="min-height:100vh;display:grid;place-items:center;padding:1.5rem;background:
    radial-gradient(900px 400px at 50% -10%, var(--accent-soft), transparent 60%), var(--bg);">
    <div class="card" style="max-width:420px;width:100%;text-align:center">
        <div class="card-body p-5">
            <div class="stat-icon mx-auto mb-3" style="width:52px;height:52px;font-size:1.3rem;background:var(--success-soft);color:var(--success)">
                <i class="fa-solid fa-check"></i>
            </div>
            <h1 class="h5 fw-bold mb-1">Thank you!</h1>
            <p class="text-muted-2 mb-0">
                <?php echo e($survey->thank_you_message ?: 'Your response has been recorded.'); ?>

            </p>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/public/survey_thanks.blade.php ENDPATH**/ ?>