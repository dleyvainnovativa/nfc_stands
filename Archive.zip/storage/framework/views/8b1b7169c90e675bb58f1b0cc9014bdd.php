<?php $__env->startSection('title', $survey->title . ' · Results'); ?>
<?php $__env->startSection('page-title', 'Survey results'); ?>

<?php use App\Models\SurveyQuestion; ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <a href="<?php echo e(route('surveys.index')); ?>" class="text-muted-2" style="font-size:.9rem">
        <i class="fa-solid fa-arrow-left me-1"></i> Surveys
    </a>
</div>

<div class="d-flex align-items-start justify-content-between flex-wrap gap-3 mb-4">
    <div>
        <h1 class="h4 fw-bold mb-1"><?php echo e($survey->title); ?></h1>
        <?php ($cls = match($survey->status){ 'active' => 'success', 'closed' => 'danger', default => 'warning' }); ?>
        <span class="badge-role" style="background:var(--<?php echo e($cls); ?>-soft);color:var(--<?php echo e($cls); ?>)"><?php echo e($survey->statusLabel()); ?></span>
        <span class="text-muted-2 ms-2" style="font-size:.9rem"><?php echo e(number_format($survey->responses_count)); ?> responses</span>
    </div>
    <a href="<?php echo e(route('surveys.edit', $survey)); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="fa-solid fa-pen me-1"></i> Edit
    </a>
</div>

<?php if(empty($results)): ?>
    <div class="card"><div class="card-body text-center text-muted-2 py-5">
        No questions yet. <a href="<?php echo e(route('surveys.edit', $survey)); ?>">Add some</a>.
    </div></div>
<?php endif; ?>

<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($q = $r['question']); ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-3 gap-2">
                <div>
                    <div class="fw-semibold"><?php echo e($q->prompt); ?></div>
                    <div class="text-subtle" style="font-size:.8rem">
                        <?php echo e(SurveyQuestion::typeOptions()[$q->type] ?? $q->type); ?> · <?php echo e($r['answered']); ?> answered
                    </div>
                </div>
            </div>

            <?php switch($q->type):
                case ('single'): ?>
                <?php case ('multi'): ?>
                    <div class="d-flex flex-column gap-2">
                        <?php $__currentLoopData = $r['data']['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="d-flex justify-content-between" style="font-size:.88rem">
                                    <span><?php echo e($row['label']); ?></span>
                                    <span class="text-muted-2"><?php echo e($row['count']); ?> · <?php echo e($row['pct']); ?>%</span>
                                </div>
                                <?php echo $__env->make('surveys._bar', ['pct' => $row['pct']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php break; ?>

                <?php case ('rating'): ?>
                    <div class="mb-3">
                        <span class="h3 fw-bold"><?php echo e($r['data']['average'] ?? '—'); ?></span>
                        <span class="text-muted-2">/ <?php echo e($r['data']['max']); ?> average (<?php echo e($r['data']['count']); ?>)</span>
                    </div>
                    <div class="d-flex flex-column gap-2">
                        <?php $__currentLoopData = $r['data']['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="d-flex justify-content-between" style="font-size:.88rem">
                                    <span><?php echo e($row['label']); ?> ★</span>
                                    <span class="text-muted-2"><?php echo e($row['count']); ?> · <?php echo e($row['pct']); ?>%</span>
                                </div>
                                <?php echo $__env->make('surveys._bar', ['pct' => $row['pct']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php break; ?>

                <?php case ('nps'): ?>
                    <?php ($d = $r['data']); ?>
                    <div class="d-flex align-items-center gap-4 flex-wrap mb-3">
                        <div>
                            <div class="stat-label">NPS</div>
                            <div class="h2 fw-bold mb-0"><?php echo e($d['score'] ?? '—'); ?></div>
                        </div>
                        <div class="flex-grow-1" style="min-width:220px">
                            <div style="display:flex;height:12px;border-radius:999px;overflow:hidden;background:var(--bg-sunken)">
                                <div style="width:<?php echo e($d['detractors_pct']); ?>%;background:var(--danger)"></div>
                                <div style="width:<?php echo e($d['passives_pct']); ?>%;background:var(--warning)"></div>
                                <div style="width:<?php echo e($d['promoters_pct']); ?>%;background:var(--success)"></div>
                            </div>
                            <div class="d-flex justify-content-between mt-2 text-muted-2" style="font-size:.8rem">
                                <span><i class="fa-solid fa-circle" style="color:var(--danger)"></i> Detractors <?php echo e($d['detractors']); ?></span>
                                <span><i class="fa-solid fa-circle" style="color:var(--warning)"></i> Passives <?php echo e($d['passives']); ?></span>
                                <span><i class="fa-solid fa-circle" style="color:var(--success)"></i> Promoters <?php echo e($d['promoters']); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php break; ?>

                <?php case ('text'): ?>
                    <?php if(empty($r['data']['recent'])): ?>
                        <div class="text-muted-2" style="font-size:.9rem">No text answers yet.</div>
                    <?php else: ?>
                        <div class="d-flex flex-column gap-2" style="max-height:320px;overflow:auto">
                            <?php $__currentLoopData = $r['data']['recent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $txt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-2 rounded" style="background:var(--bg-sunken);font-size:.9rem"><?php echo e($txt); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <?php break; ?>
            <?php endswitch; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/surveys/show.blade.php ENDPATH**/ ?>