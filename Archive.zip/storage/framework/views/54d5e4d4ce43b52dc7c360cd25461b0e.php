<?php $__env->startSection('title', 'New survey · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'New survey'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <a href="<?php echo e(route('surveys.index')); ?>" class="text-muted-2" style="font-size:.9rem">
        <i class="fa-solid fa-arrow-left me-1"></i> Surveys
    </a>
</div>

<div class="card" style="max-width:640px">
    <div class="card-body">
        <h1 class="h5 fw-bold mb-4">Create survey</h1>
        <form method="POST" action="<?php echo e(route('surveys.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" maxlength="160" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label">Description <span class="text-subtle">(optional)</span></label>
                <textarea name="description" class="form-control" rows="2" maxlength="1000"><?php echo e(old('description')); ?></textarea>
            </div>
            <div class="mb-3" style="max-width:220px">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="draft" selected>Draft</option>
                    <option value="active">Active</option>
                    <option value="closed">Closed</option>
                </select>
            </div>
            <div class="d-flex gap-2 mt-4">
                <button class="btn btn-primary">Create &amp; add questions</button>
                <a href="<?php echo e(route('surveys.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/surveys/create.blade.php ENDPATH**/ ?>