
<?php $__currentLoopData = ['success' => 'flash.success', 'error' => 'flash.error', 'warning' => 'flash.warning', 'info' => 'flash.info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session($key)): ?>
        <div data-flash="<?php echo e($type); ?>" data-flash-msg="<?php echo e(session($key)); ?>" hidden></div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($errors->any()): ?>
    <div data-flash="error" data-flash-msg="<?php echo e($errors->first()); ?>" hidden></div>
<?php endif; ?>
<?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/partials/flash.blade.php ENDPATH**/ ?>