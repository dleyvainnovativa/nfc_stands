<?php $__env->startSection('title', 'Google reviews · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Google reviews'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
    <div>
        <h1 class="h4 fw-bold mb-1">Google reviews</h1>
        <p class="text-muted-2 mb-0" style="font-size:.9rem">Rating &amp; review trends per connected place.</p>
    </div>
    <?php if($places->isNotEmpty()): ?>
        <form method="POST" action="<?php echo e(route('google.sync')); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-rotate me-1"></i> Sync all</button>
        </form>
    <?php endif; ?>
</div>

<?php if (! ($keyConfigured)): ?>
    <div class="card mb-4" style="border-left:3px solid var(--warning)">
        <div class="card-body d-flex align-items-center gap-2" style="font-size:.9rem">
            <i class="fa-solid fa-triangle-exclamation" style="color:var(--warning)"></i>
            <span><b>GOOGLE_PLACES_API_KEY</b> isn't set. Add it to <code>.env</code> (Places API New enabled) to sync.</span>
        </div>
    </div>
<?php endif; ?>


<div class="card mb-4" style="max-width:720px">
    <div class="card-body">
        <h2 class="h6 fw-bold mb-3">Connect a place</h2>
        <form method="POST" action="<?php echo e(route('google.store')); ?>" class="row g-2">
            <?php echo csrf_field(); ?>
            <div class="col-md-5">
                <input type="text" name="place_id" value="<?php echo e(old('place_id')); ?>" class="form-control"
                       placeholder="Google place ID (ChIJ…)" required>
            </div>
            <div class="col-md-4">
                <input type="text" name="label" value="<?php echo e(old('label')); ?>" class="form-control" placeholder="Label (optional)">
            </div>
            <div class="col-md-3">
                <button class="btn btn-primary w-100">Connect</button>
            </div>
        </form>
        <div class="form-text text-muted-2 mt-2">
            Find a place ID with Google's
            <a href="https://developers.google.com/maps/documentation/places/web-service/place-id" target="_blank" rel="noopener">Place ID finder</a>.
        </div>
    </div>
</div>

<?php $__empty_1 = true; $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                    <div class="fw-semibold"><?php echo e($place->displayName()); ?></div>
                    <div class="text-subtle mono" style="font-size:.78rem"><?php echo e($place->place_id); ?></div>
                    <div class="text-subtle" style="font-size:.78rem">
                        Last synced: <?php echo e($place->last_synced_at?->diffForHumans() ?? 'never'); ?>

                    </div>
                </div>
                <div class="d-flex gap-2">
                    <form method="POST" action="<?php echo e(route('google.sync.one', $place)); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-rotate"></i></button>
                    </form>
                    <form method="POST" action="<?php echo e(route('google.destroy', $place)); ?>"
                          onsubmit="return confirm('Remove this place and its history?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-outline-secondary btn-sm" style="color:var(--danger)"><i class="fa-solid fa-trash"></i></button>
                    </form>
                </div>
            </div>

            <?php if($place->sync_error): ?>
                <div class="mb-3" style="color:var(--danger);font-size:.85rem">
                    <i class="fa-solid fa-circle-exclamation me-1"></i><?php echo e($place->sync_error); ?>

                </div>
            <?php endif; ?>

            <div class="row g-3">
                <div class="col-sm-3">
                    <div class="stat-label">Rating</div>
                    <div class="stat-value"><?php echo e($place->rating !== null ? number_format($place->rating, 1) : '—'); ?>

                        <i class="fa-solid fa-star" style="color:var(--brand-gold);font-size:1rem"></i>
                    </div>
                    <div class="text-muted-2" style="font-size:.82rem"><?php echo e($place->user_rating_count !== null ? number_format($place->user_rating_count) . ' reviews' : ''); ?></div>
                </div>
                <div class="col-sm-9">
                    <div class="stat-label mb-1">Rating · last 30 days</div>
                    <canvas class="ratingChart" height="70"
                            data-labels='<?php echo json_encode($trends[$place->id]["labels"], 15, 512) ?>'
                            data-ratings='<?php echo json_encode($trends[$place->id]["ratings"], 15, 512) ?>'></canvas>
                </div>
            </div>

            <?php if(!empty($place->reviews)): ?>
                <hr class="hr-token my-3">
                <div class="stat-label mb-2">Latest reviews</div>
                <div class="d-flex flex-column gap-2">
                    <?php $__currentLoopData = $place->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-2 rounded" style="background:var(--bg-sunken)">
                            <div class="d-flex justify-content-between" style="font-size:.85rem">
                                <span class="fw-semibold"><?php echo e($rv['author'] ?? 'Anonymous'); ?></span>
                                <span class="text-muted-2">
                                    <?php echo e($rv['rating'] ?? '—'); ?> ★ · <?php echo e($rv['relative_time'] ?? ''); ?>

                                </span>
                            </div>
                            <?php if(!empty($rv['text'])): ?>
                                <div class="text-muted-2 mt-1" style="font-size:.88rem"><?php echo e(\Illuminate\Support\Str::limit($rv['text'], 280)); ?></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php if($keyConfigured): ?>
        <div class="card"><div class="card-body text-center text-muted-2 py-4">
            No places connected yet. Add a place ID above to start tracking its rating.
        </div></div>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js"></script>
<script>
(function () {
    if (!window.Chart) return;
    const css = getComputedStyle(document.documentElement);
    const gold = css.getPropertyValue('--brand-gold').trim() || '#d8a657';
    const muted = css.getPropertyValue('--text-muted').trim() || '#667085';
    const grid = css.getPropertyValue('--border').trim() || '#e4e7ec';

    document.querySelectorAll('.ratingChart').forEach((el) => {
        const labels = JSON.parse(el.dataset.labels || '[]')
            .map(d => { const x = new Date(d); return (x.getMonth()+1) + '/' + x.getDate(); });
        const ratings = JSON.parse(el.dataset.ratings || '[]');
        new Chart(el, {
            type: 'line',
            data: { labels, datasets: [{
                data: ratings, borderColor: gold, backgroundColor: gold + '22',
                fill: true, tension: 0.3, pointRadius: 0, borderWidth: 2, spanGaps: true,
            }]},
            options: {
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false }, ticks: { color: muted, maxTicksLimit: 8 } },
                    y: { min: 0, max: 5, grid: { color: grid }, ticks: { color: muted, stepSize: 1 } }
                }
            }
        });
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/google/index.blade.php ENDPATH**/ ?>