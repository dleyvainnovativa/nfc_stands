<?php $__env->startSection('title', 'Claim a tag · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Claim a tag'); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width:480px">
    <div class="card-body">
        <h1 class="h5 fw-bold mb-1">Claim a tag</h1>
        <p class="text-muted-2 mb-4" style="font-size:.9rem">
            Enter the code printed on a blank NFC tag to attach it to your account.
        </p>
        <form method="POST" action="<?php echo e(route('stands.claim.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Tag code</label>
                <input type="text" name="code" value="<?php echo e(old('code')); ?>"
                       class="form-control mono <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       placeholder="e.g. a9Kd2PqX" autofocus required>
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button class="btn btn-primary w-100">Claim tag</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/stands/claim.blade.php ENDPATH**/ ?>