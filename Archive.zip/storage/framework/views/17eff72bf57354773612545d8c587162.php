<?php
    $type = old('destination_type', $stand->destination_type);
    $existingLinks = $stand->destination_type === 'hub' ? ($stand->destination_config['links'] ?? []) : [];
    $hubTitle = $stand->destination_config['title'] ?? '';
    $directUrl = $stand->destination_type === 'direct' ? ($stand->destination_config['url'] ?? '') : '';
    $surveyId = old('survey_id', $stand->destination_type === 'survey' ? ($stand->destination_config['survey_id'] ?? '') : '');
    $placeId = old('google_place_id', $stand->destination_type === 'reviews' ? ($stand->destination_config['google_place_id'] ?? '') : '');
    $surveys = $surveys ?? collect();
    $places = $places ?? collect();
?>

<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Label</label>
        <input type="text" name="label" class="form-control" maxlength="120"
               value="<?php echo e(old('label', $stand->label)); ?>" placeholder="e.g. Table 4 / Entrance">
    </div>
    <div class="col-md-3">
        <label class="form-label">Status</label>
        <select name="status" class="form-select">
            <?php $__currentLoopData = ['active' => 'Active', 'disabled' => 'Disabled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($v); ?>" <?php if(old('status', $stand->status) === $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3">
        <label class="form-label">Type</label>
        <select name="destination_type" id="destType" class="form-select">
            <?php $__currentLoopData = \App\Models\Stand::typeOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($v); ?>" <?php if($type === $v): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<hr class="hr-token my-4">


<div data-dest="direct" class="<?php echo e($type === 'direct' ? '' : 'd-none'); ?>">
    <label class="form-label">Destination URL</label>
    <input type="url" name="url" class="form-control" maxlength="2048"
           value="<?php echo e(old('url', $directUrl)); ?>" placeholder="https://…">
    <div class="form-text text-muted-2">The tag redirects straight here on scan.</div>
</div>


<div data-dest="survey" class="<?php echo e($type === 'survey' ? '' : 'd-none'); ?>">
    <label class="form-label">Survey</label>
    <?php if($surveys->isEmpty()): ?>
        <div class="text-muted-2" style="font-size:.9rem">No surveys yet. <a href="<?php echo e(route('surveys.create')); ?>">Create one</a> first.</div>
    <?php else: ?>
        <select name="survey_id" class="form-select">
            <option value="">Choose a survey…</option>
            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s->id); ?>" <?php if((string)$surveyId === (string)$s->id): echo 'selected'; endif; ?>>
                    <?php echo e($s->title); ?> <?php if($s->status !== 'active'): ?> (<?php echo e(ucfirst($s->status)); ?>) <?php endif; ?>
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="form-text text-muted-2">Only <b>active</b> surveys collect responses.</div>
    <?php endif; ?>
</div>


<div data-dest="reviews" class="<?php echo e($type === 'reviews' ? '' : 'd-none'); ?>">
    <label class="form-label">Google place</label>
    <?php if($places->isEmpty()): ?>
        <div class="text-muted-2" style="font-size:.9rem">No places connected. <a href="<?php echo e(route('google.index')); ?>">Connect one</a> first.</div>
    <?php else: ?>
        <select name="google_place_id" class="form-select">
            <option value="">Choose a place…</option>
            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>" <?php if((string)$placeId === (string)$p->id): echo 'selected'; endif; ?>>
                    <?php echo e($p->label ?: $p->name ?: $p->place_id); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="form-text text-muted-2">Scanners go straight to the Google "write a review" screen for this place.</div>
    <?php endif; ?>
</div>


<div data-dest="hub" class="<?php echo e($type === 'hub' ? '' : 'd-none'); ?>">
    <div class="mb-3">
        <label class="form-label">Hub title</label>
        <input type="text" name="hub_title" class="form-control" maxlength="120"
               value="<?php echo e(old('hub_title', $hubTitle)); ?>" placeholder="Shown above the buttons">
    </div>

    <label class="form-label">Links</label>
    <div id="linkRows" class="d-flex flex-column gap-2">
        <?php ($rows = old('link_url') ? array_map(fn($u,$i)=>['label'=>old('link_label')[$i]??'','url'=>$u], old('link_url'), array_keys(old('link_url'))) : $existingLinks); ?>
        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="d-flex gap-2 link-row">
                <input type="text" name="link_label[]" class="form-control" placeholder="Button label" value="<?php echo e($link['label'] ?? ''); ?>">
                <input type="url" name="link_url[]" class="form-control" placeholder="https://…" value="<?php echo e($link['url'] ?? ''); ?>">
                <button type="button" class="btn btn-outline-secondary remove-row"><i class="fa-solid fa-xmark"></i></button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="d-flex gap-2 link-row">
                <input type="text" name="link_label[]" class="form-control" placeholder="Button label">
                <input type="url" name="link_url[]" class="form-control" placeholder="https://…">
                <button type="button" class="btn btn-outline-secondary remove-row"><i class="fa-solid fa-xmark"></i></button>
            </div>
        <?php endif; ?>
    </div>
    <button type="button" id="addLink" class="btn btn-outline-secondary btn-sm mt-2">
        <i class="fa-solid fa-plus me-1"></i> Add link
    </button>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    (function () {
        const type = document.getElementById('destType');
        const panels = document.querySelectorAll('[data-dest]');
        function sync() { panels.forEach(p => p.classList.toggle('d-none', p.dataset.dest !== type.value)); }
        type.addEventListener('change', sync); sync();

        const rows = document.getElementById('linkRows');
        document.getElementById('addLink')?.addEventListener('click', () => {
            const row = rows.querySelector('.link-row').cloneNode(true);
            row.querySelectorAll('input').forEach(i => i.value = '');
            rows.appendChild(row);
        });
        rows?.addEventListener('click', (e) => {
            if (e.target.closest('.remove-row') && rows.querySelectorAll('.link-row').length > 1) {
                e.target.closest('.link-row').remove();
            }
        });
    })();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/stands/_form.blade.php ENDPATH**/ ?>