<div style="height:8px;border-radius:999px;background:var(--bg-sunken);overflow:hidden;margin-top:3px">
    <div style="height:100%;width:<?php echo e(max(0, min(100, $pct))); ?>%;background:var(--accent);border-radius:999px"></div>
</div>
<?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/surveys/_bar.blade.php ENDPATH**/ ?>