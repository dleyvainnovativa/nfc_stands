<?php $__env->startSection('title', 'Dashboard · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-2">
    <div>
        <h1 class="h4 fw-bold mb-1">Overview</h1>
        <p class="text-muted-2 mb-0" style="font-size:.92rem">
            Scope: <span class="fw-semibold"><?php echo e($scope); ?></span>
        </p>
    </div>
    <?php if (! ($platformView)): ?>
        <a href="<?php echo e(route('stands.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-plus me-1"></i> New stand
        </a>
    <?php endif; ?>
</div>

<div class="row g-3 mb-4">
    <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-xl-3">
            <div class="card stat-card h-100">
                <div class="d-flex align-items-start justify-content-between">
                    <div>
                        <div class="stat-label"><?php echo e($s['label']); ?></div>
                        <div class="stat-value"><?php echo e($s['value']); ?></div>
                    </div>
                    <div class="stat-icon"><i class="fa-solid <?php echo e($s['icon']); ?>"></i></div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="card">
    <div class="card-body d-flex align-items-center gap-3 flex-wrap">
        <div class="stat-icon"><i class="fa-solid fa-wifi"></i></div>
        <div class="flex-grow-1">
            <div class="fw-semibold">Manage your stands</div>
            <div class="text-muted-2" style="font-size:.9rem">
                Create stands, set where each tag points, and watch scans roll in.
            </div>
        </div>
        <a href="<?php echo e(route('stands.index')); ?>" class="btn btn-outline-secondary btn-sm">Go to stands</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/dashboard/index.blade.php ENDPATH**/ ?>