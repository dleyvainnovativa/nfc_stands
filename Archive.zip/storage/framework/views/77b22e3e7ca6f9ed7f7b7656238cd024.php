<?php $__env->startSection('title', 'Surveys · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'Surveys'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <h1 class="h4 fw-bold mb-0">Surveys</h1>
    <a href="<?php echo e(route('surveys.create')); ?>" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-plus me-1"></i> New survey
    </a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr class="text-muted-2" style="font-size:.8rem">
                    <th class="ps-3">Title</th><th>Status</th><th>Questions</th>
                    <th class="text-end">Responses</th><th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-3 fw-semibold"><?php echo e($survey->title); ?></td>
                        <td>
                            <?php ($cls = match($survey->status){ 'active' => 'success', 'closed' => 'danger', default => 'warning' }); ?>
                            <span class="badge-role" style="background:var(--<?php echo e($cls); ?>-soft);color:var(--<?php echo e($cls); ?>)">
                                <?php echo e($survey->statusLabel()); ?>

                            </span>
                        </td>
                        <td class="text-muted-2"><?php echo e($survey->questions_count); ?></td>
                        <td class="text-end mono"><?php echo e(number_format($survey->responses_count)); ?></td>
                        <td class="text-end pe-3">
                            <a href="<?php echo e(route('surveys.show', $survey)); ?>" class="btn btn-sm btn-outline-secondary">Results</a>
                            <a href="<?php echo e(route('surveys.edit', $survey)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-center text-muted-2 py-5">
                        No surveys yet. <a href="<?php echo e(route('surveys.create')); ?>">Create one</a>.
                    </td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3"><?php echo e($surveys->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/surveys/index.blade.php ENDPATH**/ ?>