<?php $__env->startSection('title', 'New stand · NFC Stands'); ?>
<?php $__env->startSection('page-title', 'New stand'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3">
    <a href="<?php echo e(route('stands.index')); ?>" class="text-muted-2" style="font-size:.9rem">
        <i class="fa-solid fa-arrow-left me-1"></i> Stands
    </a>
</div>

<div class="card" style="max-width:720px">
    <div class="card-body">
        <h1 class="h5 fw-bold mb-4">Create stand</h1>
        <form method="POST" action="<?php echo e(route('stands.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('stands._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="d-flex gap-2 mt-4">
                <button class="btn btn-primary">Create stand</button>
                <a href="<?php echo e(route('stands.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/stands/create.blade.php ENDPATH**/ ?>