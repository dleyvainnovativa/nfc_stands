<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
      data-theme="<?php echo e(request()->cookie('theme', 'light')); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($survey->title); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <style>
        .scale { display:flex; flex-wrap:wrap; gap:.4rem; }
        .scale input { position:absolute; opacity:0; }
        .scale label {
            min-width:40px; text-align:center; padding:.5rem .4rem; cursor:pointer;
            border:1px solid var(--border-strong); border-radius:var(--radius);
            color:var(--text-muted); font-weight:600; user-select:none;
        }
        .scale input:checked + label { background:var(--accent); border-color:var(--accent); color:#fff; }
        .opt { display:flex; align-items:center; gap:.6rem; padding:.6rem .8rem;
               border:1px solid var(--border); border-radius:var(--radius); cursor:pointer; }
        .opt:hover { background:var(--surface-hover); }
    </style>
</head>
<body>
<div style="min-height:100vh;display:grid;place-items:start center;padding:2rem 1rem;background:
    radial-gradient(900px 400px at 50% -10%, var(--accent-soft), transparent 60%), var(--bg);">
    <div style="width:100%;max-width:520px">
        <div class="mb-4">
            <h1 class="h4 fw-bold mb-1"><?php echo e($survey->title); ?></h1>
            <?php if($survey->description): ?>
                <p class="text-muted-2 mb-0"><?php echo e($survey->description); ?></p>
            <?php endif; ?>
        </div>

        <form method="POST" action="<?php echo e(route('survey.public.submit', $survey->code)); ?>">
            <?php echo csrf_field(); ?>
            <?php if($via): ?><input type="hidden" name="via" value="<?php echo e($via); ?>"><?php endif; ?>

            <div class="d-flex flex-column gap-3">
                <?php $__currentLoopData = $survey->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($err = $errors->first("answers.{$q->id}")); ?>
                    <div class="card">
                        <div class="card-body">
                            <label class="fw-semibold d-block mb-2">
                                <?php echo e($q->prompt); ?>

                                <?php if($q->required): ?><span style="color:var(--danger)">*</span><?php endif; ?>
                            </label>

                            <?php switch($q->type):
                                case ('single'): ?>
                                    <div class="d-flex flex-column gap-2">
                                        <?php $__currentLoopData = $q->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="opt">
                                                <input type="radio" name="answers[<?php echo e($q->id); ?>]" value="<?php echo e($opt); ?>"
                                                       <?php if(old("answers.{$q->id}") === $opt): echo 'checked'; endif; ?>>
                                                <span><?php echo e($opt); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php break; ?>

                                <?php case ('multi'): ?>
                                    <div class="d-flex flex-column gap-2">
                                        <?php $__currentLoopData = $q->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="opt">
                                                <input type="checkbox" name="answers[<?php echo e($q->id); ?>][]" value="<?php echo e($opt); ?>"
                                                       <?php if(in_array($opt, (array) old("answers.{$q->id}", []))): echo 'checked'; endif; ?>>
                                                <span><?php echo e($opt); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <?php break; ?>

                                <?php case ('rating'): ?>
                                    <div class="scale">
                                        <?php for($n = 1; $n <= $q->ratingMax(); $n++): ?>
                                            <span style="position:relative">
                                                <input type="radio" id="q<?php echo e($q->id); ?>_<?php echo e($n); ?>" name="answers[<?php echo e($q->id); ?>]" value="<?php echo e($n); ?>"
                                                       <?php if((string)old("answers.{$q->id}") === (string)$n): echo 'checked'; endif; ?>>
                                                <label for="q<?php echo e($q->id); ?>_<?php echo e($n); ?>"><?php echo e($n); ?></label>
                                            </span>
                                        <?php endfor; ?>
                                    </div>
                                    <?php break; ?>

                                <?php case ('nps'): ?>
                                    <div class="scale">
                                        <?php for($n = 0; $n <= 10; $n++): ?>
                                            <span style="position:relative">
                                                <input type="radio" id="q<?php echo e($q->id); ?>_<?php echo e($n); ?>" name="answers[<?php echo e($q->id); ?>]" value="<?php echo e($n); ?>"
                                                       <?php if((string)old("answers.{$q->id}") === (string)$n): echo 'checked'; endif; ?>>
                                                <label for="q<?php echo e($q->id); ?>_<?php echo e($n); ?>"><?php echo e($n); ?></label>
                                            </span>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="d-flex justify-content-between text-subtle mt-1" style="font-size:.78rem">
                                        <span>Not likely</span><span>Very likely</span>
                                    </div>
                                    <?php break; ?>

                                <?php case ('text'): ?>
                                    <textarea name="answers[<?php echo e($q->id); ?>]" class="form-control" rows="3" maxlength="2000"
                                              placeholder="Your answer"><?php echo e(old("answers.{$q->id}")); ?></textarea>
                                    <?php break; ?>
                            <?php endswitch; ?>

                            <?php if($err): ?>
                                <div style="color:var(--danger);font-size:.82rem;margin-top:.5rem"><?php echo e($err); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button class="btn btn-primary w-100 mt-4">Submit</button>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH /Volumes/SSDick/Documents/Projects/nfc_stands/resources/views/public/survey.blade.php ENDPATH**/ ?>