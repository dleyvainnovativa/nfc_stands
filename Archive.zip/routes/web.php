<?php

use App\Http\Controllers\Admin\TagBatchController;
use App\Http\Controllers\Admin\TagQrController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\GooglePlaceController;
use App\Http\Controllers\Public\HubLinkController;
use App\Http\Controllers\Public\StandRedirectController;
use App\Http\Controllers\Public\SurveyResponseController;
use App\Http\Controllers\StandClaimController;
use App\Http\Controllers\StandController;
use App\Http\Controllers\StandQrController;
use App\Http\Controllers\SurveyController;
use App\Http\Controllers\TenantSwitchController;
use App\Models\User;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public — no auth, no tenant scope
|--------------------------------------------------------------------------
*/
Route::get('/t/{code}', [StandRedirectController::class, 'show'])->name('stand.public');
Route::get('/t/{code}/go/{i}', [HubLinkController::class, 'go'])->whereNumber('i')->name('stand.link');

Route::get('/s/{code}', [SurveyResponseController::class, 'show'])->name('survey.public');
Route::post('/s/{code}', [SurveyResponseController::class, 'store'])->name('survey.public.submit');

/*
|--------------------------------------------------------------------------
| Guest
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'show'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])->name('login.store');
});

Route::redirect('/', '/login');

/*
|--------------------------------------------------------------------------
| Authenticated
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'role:' . User::ROLE_SUPER_ADMIN . ',' . User::ROLE_CLIENT_ADMIN])->group(function () {

    Route::post('/logout', [LoginController::class, 'destroy'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    /* ---- Stands ---- */
    Route::get('/stands/claim', [StandClaimController::class, 'show'])->name('stands.claim');
    Route::post('/stands/claim', [StandClaimController::class, 'store'])->name('stands.claim.store');
    Route::resource('stands', StandController::class)->except(['show']);
    Route::get('/stands/{stand}', [StandController::class, 'show'])->name('stands.show');
    Route::get('/stands/{stand}/qr', [StandQrController::class, 'svg'])->name('stands.qr');
    Route::get('/stands/{stand}/qr/print', [StandQrController::class, 'print'])->name('stands.qr.print');

    /* ---- Surveys ---- */
    Route::resource('surveys', SurveyController::class);

    /* ---- Google reviews ---- */
    Route::get('/google', [GooglePlaceController::class, 'index'])->name('google.index');
    Route::post('/google', [GooglePlaceController::class, 'store'])->name('google.store');
    Route::post('/google/sync', [GooglePlaceController::class, 'sync'])->name('google.sync');
    Route::post('/google/{place}/sync', [GooglePlaceController::class, 'sync'])->name('google.sync.one');
    Route::delete('/google/{place}', [GooglePlaceController::class, 'destroy'])->name('google.destroy');

    /* ---- Super-admin only ---- */
    Route::middleware('role:' . User::ROLE_SUPER_ADMIN)->group(function () {
        Route::post('/switch/{tenant}', [TenantSwitchController::class, 'enter'])->name('tenant.enter');
        Route::post('/switch-exit', [TenantSwitchController::class, 'exit'])->name('tenant.exit');

        Route::get('/admin/tags', [TagBatchController::class, 'index'])->name('admin.tags.index');
        Route::post('/admin/tags', [TagBatchController::class, 'store'])->name('admin.tags.store');
        Route::get('/admin/tags/export', [TagBatchController::class, 'export'])->name('admin.tags.export');
        Route::get('/admin/tags/qr-sheet', [TagQrController::class, 'sheet'])->name('admin.tags.qr_sheet');
    });
});
