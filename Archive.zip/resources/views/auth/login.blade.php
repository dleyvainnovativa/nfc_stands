@extends('layouts.guest')
@section('title', 'Sign in · NFC Stands')

@section('content')
<div class="auth-card">
    <div class="brand-row">
        <span class="logo-mark"><i class="fa-solid fa-wifi"></i></span>
        <span>NFC Stands</span>
    </div>

    <h1 class="h5 fw-bold text-center mb-1">Sign in</h1>
    <p class="text-center text-muted-2 mb-4" style="font-size:.9rem">
        Access your dashboard
    </p>

    <form method="POST" action="{{ route('login.store') }}" novalidate>
        @csrf

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}"
                   class="form-control @error('email') is-invalid @enderror"
                   autocomplete="email" autofocus required>
            @error('email') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" id="password" name="password"
                   class="form-control @error('password') is-invalid @enderror"
                   autocomplete="current-password" required>
            @error('password') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="form-check mb-4">
            <input type="checkbox" class="form-check-input" id="remember" name="remember">
            <label class="form-check-label text-muted-2" for="remember" style="font-size:.88rem">
                Keep me signed in
            </label>
        </div>

        <button type="submit" class="btn btn-primary w-100">
            <i class="fa-solid fa-arrow-right-to-bracket me-1"></i> Sign in
        </button>
    </form>
</div>
@endsection
