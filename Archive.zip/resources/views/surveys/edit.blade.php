@extends('layouts.app')
@section('title', 'Edit survey · NFC Stands')
@section('page-title', 'Edit survey')

@php
    use App\Models\SurveyQuestion;
    $typeOpts = SurveyQuestion::typeOptions();
@endphp

@section('content')
<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <a href="{{ route('surveys.index') }}" class="text-muted-2" style="font-size:.9rem">
        <i class="fa-solid fa-arrow-left me-1"></i> Surveys
    </a>
    <div class="d-flex align-items-center gap-2">
        <code class="text-muted-2" style="font-size:.82rem">{{ $survey->publicUrl() }}</code>
        <a href="{{ route('surveys.show', $survey) }}" class="btn btn-outline-secondary btn-sm">Results</a>
    </div>
</div>

<form method="POST" action="{{ route('surveys.update', $survey) }}">
    @csrf @method('PUT')

    {{-- Meta --}}
    <div class="card mb-4" style="max-width:820px">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" value="{{ old('title', $survey->title) }}" class="form-control" maxlength="160" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        @foreach (['draft'=>'Draft','active'=>'Active','closed'=>'Closed'] as $v=>$l)
                            <option value="{{ $v }}" @selected(old('status',$survey->status)===$v)>{{ $l }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">Description <span class="text-subtle">(optional)</span></label>
                    <textarea name="description" class="form-control" rows="2" maxlength="1000">{{ old('description', $survey->description) }}</textarea>
                </div>
                <div class="col-12">
                    <label class="form-label">Thank-you message <span class="text-subtle">(optional)</span></label>
                    <input type="text" name="thank_you_message" value="{{ old('thank_you_message', $survey->thank_you_message) }}" class="form-control" maxlength="300" placeholder="Thanks for your feedback!">
                </div>
            </div>
        </div>
    </div>

    {{-- Questions --}}
    <div class="d-flex align-items-center justify-content-between mb-2" style="max-width:820px">
        <h2 class="h6 fw-bold mb-0">Questions</h2>
    </div>

    <div id="questions" class="d-flex flex-column gap-3" style="max-width:820px">
        @foreach ($survey->questions as $i => $q)
            @include('surveys._question_row', [
                'idx' => $i,
                'q' => $q,
            ])
        @endforeach
    </div>

    <div class="mt-3" style="max-width:820px">
        <button type="button" id="addQuestion" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-plus me-1"></i> Add question
        </button>
    </div>

    <div class="d-flex gap-2 mt-4" style="max-width:820px">
        <button class="btn btn-primary">Save survey</button>
        <a href="{{ route('surveys.index') }}" class="btn btn-outline-secondary">Done</a>
    </div>
</form>

{{-- Template for new question rows --}}
<template id="qTemplate">
    @include('surveys._question_row', ['idx' => '__IDX__', 'q' => null])
</template>

@push('scripts')
<script>
(function () {
    const wrap = document.getElementById('questions');
    const tpl = document.getElementById('qTemplate').innerHTML;
    let counter = {{ $survey->questions->count() }};

    function wire(row) {
        const typeSel = row.querySelector('[data-role="type"]');
        const toggle = () => {
            const t = typeSel.value;
            row.querySelector('[data-for="options"]').classList.toggle('d-none', !(t === 'single' || t === 'multi'));
            row.querySelector('[data-for="rating"]').classList.toggle('d-none', t !== 'rating');
        };
        typeSel.addEventListener('change', toggle); toggle();

        row.querySelector('[data-act="remove"]').addEventListener('click', () => row.remove());
        row.querySelector('[data-act="up"]').addEventListener('click', () => {
            const prev = row.previousElementSibling; if (prev) wrap.insertBefore(row, prev);
        });
        row.querySelector('[data-act="down"]').addEventListener('click', () => {
            const next = row.nextElementSibling; if (next) wrap.insertBefore(next, row);
        });
    }

    wrap.querySelectorAll('.q-row').forEach(wire);

    document.getElementById('addQuestion').addEventListener('click', () => {
        const html = tpl.replaceAll('__IDX__', 'n' + (counter++));
        const tmp = document.createElement('div');
        tmp.innerHTML = html.trim();
        const row = tmp.firstElementChild;
        wrap.appendChild(row);
        wire(row);
    });
})();
</script>
@endpush
@endsection
