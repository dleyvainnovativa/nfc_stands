@extends('layouts.app')
@section('title', 'Surveys · NFC Stands')
@section('page-title', 'Surveys')

@section('content')
<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <h1 class="h4 fw-bold mb-0">Surveys</h1>
    <a href="{{ route('surveys.create') }}" class="btn btn-primary btn-sm">
        <i class="fa-solid fa-plus me-1"></i> New survey
    </a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr class="text-muted-2" style="font-size:.8rem">
                    <th class="ps-3">Title</th><th>Status</th><th>Questions</th>
                    <th class="text-end">Responses</th><th></th>
                </tr>
            </thead>
            <tbody>
                @forelse ($surveys as $survey)
                    <tr>
                        <td class="ps-3 fw-semibold">{{ $survey->title }}</td>
                        <td>
                            @php($cls = match($survey->status){ 'active' => 'success', 'closed' => 'danger', default => 'warning' })
                            <span class="badge-role" style="background:var(--{{ $cls }}-soft);color:var(--{{ $cls }})">
                                {{ $survey->statusLabel() }}
                            </span>
                        </td>
                        <td class="text-muted-2">{{ $survey->questions_count }}</td>
                        <td class="text-end mono">{{ number_format($survey->responses_count) }}</td>
                        <td class="text-end pe-3">
                            <a href="{{ route('surveys.show', $survey) }}" class="btn btn-sm btn-outline-secondary">Results</a>
                            <a href="{{ route('surveys.edit', $survey) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="text-center text-muted-2 py-5">
                        No surveys yet. <a href="{{ route('surveys.create') }}">Create one</a>.
                    </td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">{{ $surveys->links() }}</div>
@endsection
