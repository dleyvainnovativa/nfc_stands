<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}"
      data-theme="{{ request()->cookie('theme', 'light') }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $survey->title }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    @vite(['resources/js/app.js'])
    <style>
        .scale { display:flex; flex-wrap:wrap; gap:.4rem; }
        .scale input { position:absolute; opacity:0; }
        .scale label {
            min-width:40px; text-align:center; padding:.5rem .4rem; cursor:pointer;
            border:1px solid var(--border-strong); border-radius:var(--radius);
            color:var(--text-muted); font-weight:600; user-select:none;
        }
        .scale input:checked + label { background:var(--accent); border-color:var(--accent); color:#fff; }
        .opt { display:flex; align-items:center; gap:.6rem; padding:.6rem .8rem;
               border:1px solid var(--border); border-radius:var(--radius); cursor:pointer; }
        .opt:hover { background:var(--surface-hover); }
    </style>
</head>
<body>
<div style="min-height:100vh;display:grid;place-items:start center;padding:2rem 1rem;background:
    radial-gradient(900px 400px at 50% -10%, var(--accent-soft), transparent 60%), var(--bg);">
    <div style="width:100%;max-width:520px">
        <div class="mb-4">
            <h1 class="h4 fw-bold mb-1">{{ $survey->title }}</h1>
            @if ($survey->description)
                <p class="text-muted-2 mb-0">{{ $survey->description }}</p>
            @endif
        </div>

        <form method="POST" action="{{ route('survey.public.submit', $survey->code) }}">
            @csrf
            @if ($via)<input type="hidden" name="via" value="{{ $via }}">@endif

            <div class="d-flex flex-column gap-3">
                @foreach ($survey->questions as $q)
                    @php($err = $errors->first("answers.{$q->id}"))
                    <div class="card">
                        <div class="card-body">
                            <label class="fw-semibold d-block mb-2">
                                {{ $q->prompt }}
                                @if ($q->required)<span style="color:var(--danger)">*</span>@endif
                            </label>

                            @switch($q->type)
                                @case('single')
                                    <div class="d-flex flex-column gap-2">
                                        @foreach ($q->options as $opt)
                                            <label class="opt">
                                                <input type="radio" name="answers[{{ $q->id }}]" value="{{ $opt }}"
                                                       @checked(old("answers.{$q->id}") === $opt)>
                                                <span>{{ $opt }}</span>
                                            </label>
                                        @endforeach
                                    </div>
                                    @break

                                @case('multi')
                                    <div class="d-flex flex-column gap-2">
                                        @foreach ($q->options as $opt)
                                            <label class="opt">
                                                <input type="checkbox" name="answers[{{ $q->id }}][]" value="{{ $opt }}"
                                                       @checked(in_array($opt, (array) old("answers.{$q->id}", [])))>
                                                <span>{{ $opt }}</span>
                                            </label>
                                        @endforeach
                                    </div>
                                    @break

                                @case('rating')
                                    <div class="scale">
                                        @for ($n = 1; $n <= $q->ratingMax(); $n++)
                                            <span style="position:relative">
                                                <input type="radio" id="q{{ $q->id }}_{{ $n }}" name="answers[{{ $q->id }}]" value="{{ $n }}"
                                                       @checked((string)old("answers.{$q->id}") === (string)$n)>
                                                <label for="q{{ $q->id }}_{{ $n }}">{{ $n }}</label>
                                            </span>
                                        @endfor
                                    </div>
                                    @break

                                @case('nps')
                                    <div class="scale">
                                        @for ($n = 0; $n <= 10; $n++)
                                            <span style="position:relative">
                                                <input type="radio" id="q{{ $q->id }}_{{ $n }}" name="answers[{{ $q->id }}]" value="{{ $n }}"
                                                       @checked((string)old("answers.{$q->id}") === (string)$n)>
                                                <label for="q{{ $q->id }}_{{ $n }}">{{ $n }}</label>
                                            </span>
                                        @endfor
                                    </div>
                                    <div class="d-flex justify-content-between text-subtle mt-1" style="font-size:.78rem">
                                        <span>Not likely</span><span>Very likely</span>
                                    </div>
                                    @break

                                @case('text')
                                    <textarea name="answers[{{ $q->id }}]" class="form-control" rows="3" maxlength="2000"
                                              placeholder="Your answer">{{ old("answers.{$q->id}") }}</textarea>
                                    @break
                            @endswitch

                            @if ($err)
                                <div style="color:var(--danger);font-size:.82rem;margin-top:.5rem">{{ $err }}</div>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>

            <button class="btn btn-primary w-100 mt-4">Submit</button>
        </form>
    </div>
</div>
</body>
</html>
