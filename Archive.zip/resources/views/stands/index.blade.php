@extends('layouts.app')
@section('title', 'Stands · NFC Stands')
@section('page-title', 'Stands')

@section('content')
<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <h1 class="h4 fw-bold mb-0">Stands</h1>
    <div class="d-flex gap-2">
        <a href="{{ route('stands.claim') }}" class="btn btn-outline-secondary btn-sm">
            <i class="fa-solid fa-plus-circle me-1"></i> Claim a tag
        </a>
        <a href="{{ route('stands.create') }}" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-plus me-1"></i> New stand
        </a>
    </div>
</div>

<form method="GET" class="row g-2 mb-3" style="max-width:560px">
    <div class="col">
        <input type="text" name="q" value="{{ request('q') }}" class="form-control form-control-sm"
               placeholder="Search label or code…">
    </div>
    <div class="col-auto">
        <select name="status" class="form-select form-select-sm">
            <option value="">All statuses</option>
            @foreach (['active' => 'Active', 'unassigned' => 'Unassigned', 'disabled' => 'Disabled'] as $v => $l)
                <option value="{{ $v }}" @selected(request('status') === $v)>{{ $l }}</option>
            @endforeach
        </select>
    </div>
    <div class="col-auto">
        <button class="btn btn-outline-secondary btn-sm">Filter</button>
    </div>
</form>

<div class="card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr class="text-muted-2" style="font-size:.8rem">
                    <th class="ps-3">Label</th>
                    <th>Code</th>
                    <th>Destination</th>
                    <th>Status</th>
                    <th class="text-end">Scans</th>
                    <th>Last scan</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @forelse ($stands as $stand)
                    <tr>
                        <td class="ps-3 fw-semibold">{{ $stand->label ?: '—' }}</td>
                        <td><code>{{ $stand->code }}</code></td>
                        <td class="text-muted-2">{{ \App\Models\Stand::typeOptions()[$stand->destination_type] ?? $stand->destination_type }}</td>
                        <td>
                            @php($cls = match($stand->status){ 'active' => 'success', 'disabled' => 'danger', default => 'warning' })
                            <span class="badge-role" style="background:var(--{{ $cls }}-soft);color:var(--{{ $cls }})">
                                {{ $stand->statusLabel() }}
                            </span>
                        </td>
                        <td class="text-end mono">{{ number_format($stand->scans_total) }}</td>
                        <td class="text-muted-2" style="font-size:.86rem">
                            {{ $stand->last_scan_at?->diffForHumans() ?? '—' }}
                        </td>
                        <td class="text-end pe-3">
                            <a href="{{ route('stands.show', $stand) }}" class="btn btn-sm btn-outline-secondary">Open</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted-2 py-5">
                            No stands yet. <a href="{{ route('stands.create') }}">Create one</a> or
                            <a href="{{ route('stands.claim') }}">claim a tag</a>.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">{{ $stands->links() }}</div>
@endsection
