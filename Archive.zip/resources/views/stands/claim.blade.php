@extends('layouts.app')
@section('title', 'Claim a tag · NFC Stands')
@section('page-title', 'Claim a tag')

@section('content')
<div class="card" style="max-width:480px">
    <div class="card-body">
        <h1 class="h5 fw-bold mb-1">Claim a tag</h1>
        <p class="text-muted-2 mb-4" style="font-size:.9rem">
            Enter the code printed on a blank NFC tag to attach it to your account.
        </p>
        <form method="POST" action="{{ route('stands.claim.store') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label">Tag code</label>
                <input type="text" name="code" value="{{ old('code') }}"
                       class="form-control mono @error('code') is-invalid @enderror"
                       placeholder="e.g. a9Kd2PqX" autofocus required>
                @error('code') <div class="invalid-feedback">{{ $message }}</div> @enderror
            </div>
            <button class="btn btn-primary w-100">Claim tag</button>
        </form>
    </div>
</div>
@endsection
