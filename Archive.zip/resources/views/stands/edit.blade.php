@extends('layouts.app')
@section('title', 'Edit stand · NFC Stands')
@section('page-title', 'Edit stand')

@section('content')
<div class="mb-3">
    <a href="{{ route('stands.show', $stand) }}" class="text-muted-2" style="font-size:.9rem">
        <i class="fa-solid fa-arrow-left me-1"></i> Back to stand
    </a>
</div>

<div class="card" style="max-width:720px">
    <div class="card-body">
        <h1 class="h5 fw-bold mb-1">Edit stand</h1>
        <p class="text-muted-2 mb-4" style="font-size:.9rem">
            Code <code>{{ $stand->code }}</code> · changes take effect on the next scan.
        </p>
        <form method="POST" action="{{ route('stands.update', $stand) }}">
            @csrf @method('PUT')
            @include('stands._form')
            <div class="d-flex gap-2 mt-4">
                <button class="btn btn-primary">Save changes</button>
                <a href="{{ route('stands.show', $stand) }}" class="btn btn-outline-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
